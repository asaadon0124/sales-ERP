<?php

namespace App\Livewire\BackEnd\TreasuryTransation;

use Livewire\Component;

class Show extends Component
{
    public function render()
    {
        return view('back-end.treasury-transation.show');
    }
}
