<?php

namespace App\Livewire\BackEnd\ItemCardMovement;

use Livewire\Component;

class Create extends Component
{
    public function render()
    {
        return view('back-end.item-card-movement.create');
    }
}
