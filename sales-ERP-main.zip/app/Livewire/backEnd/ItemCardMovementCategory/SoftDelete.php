<?php

namespace App\Livewire\BackEnd\ItemCardMovementCategory;

use Livewire\Component;

class SoftDelete extends Component
{
    public function render()
    {
        return view('back-end.item-card-movement-category.soft-delete');
    }
}
