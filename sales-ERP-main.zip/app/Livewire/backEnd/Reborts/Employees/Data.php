<?php

namespace App\Livewire\BackEnd\Reborts\Employees;

use Livewire\Component;

class Data extends Component
{
    public function render()
    {
        return view('back-end.reborts.employees.data');
    }
}
