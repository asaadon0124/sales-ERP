<?php

namespace App\Livewire\BackEnd\ItemCardMovementType;

use Livewire\Component;

class Delete extends Component
{
    public function render()
    {
        return view('back-end.item-card-movement-type.delete');
    }
}
