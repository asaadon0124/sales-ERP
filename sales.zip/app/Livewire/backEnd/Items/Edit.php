<?php

namespace App\Livewire\BackEnd\Items;

use Livewire\Component;

class Edit extends Component
{
    public function render()
    {
        return view('back-end.items.edit');
    }
}
