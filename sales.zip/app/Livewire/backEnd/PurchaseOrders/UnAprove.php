<?php

namespace App\Livewire\BackEnd\PurchaseOrders;

use Livewire\Component;

class UnAprove extends Component
{

   


    public function render()
    {
        return view('back-end.purchase-orders.un-aprove');
    }
}
