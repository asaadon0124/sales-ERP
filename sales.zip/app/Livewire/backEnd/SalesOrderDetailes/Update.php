<?php

namespace App\Livewire\BackEnd\SalesOrderDetailes;

use Livewire\Component;

class Update extends Component
{
    public function render()
    {
        return view('back-end.sales-order-detailes.update');
    }
}
