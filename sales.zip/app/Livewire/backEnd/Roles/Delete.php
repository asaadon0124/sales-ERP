<?php

namespace App\Livewire\BackEnd\Roles;

use Livewire\Component;

class Delete extends Component
{
    public function render()
    {
        return view('back-end.roles.delete');
    }
}
