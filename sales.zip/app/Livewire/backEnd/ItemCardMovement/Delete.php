<?php

namespace App\Livewire\BackEnd\ItemCardMovement;

use Livewire\Component;

class Delete extends Component
{
    public function render()
    {
        return view('back-end.item-card-movement.delete');
    }
}
